# mslearn-ai-services
Lab files for Azure AI Services modules
